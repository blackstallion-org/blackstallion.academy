"use server";

import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { LEAD_STATUSES } from "@/lib/admin/constants";
import { uuidSchema } from "@/lib/admin/filters";
import { logAdminError } from "@/lib/admin/server";
import { requireStaff } from "@/lib/auth/admin";
import { destinationAfterSignIn } from "@/lib/auth/destination";
import { classifyAuthError } from "@/lib/auth/errors";
import { consumeRateLimit } from "@/lib/security/rate-limit";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { objectPath, validateUpload } from "@/lib/storage/validate";

export type FormState = { error?: string; notice?: string; unconfirmed?: boolean } | null;

async function client() {
  const h = await headers();
  return { ip: (h.get("x-forwarded-for")?.split(",")[0] || h.get("x-real-ip") || "unknown").trim().slice(0, 64), host: h.get("x-forwarded-host") || h.get("host") || "", proto: h.get("x-forwarded-proto") || "https" };
}

const credentials = z.object({ email: z.string().trim().email().max(160), password: z.string().min(8).max(200) });

/**
 * Sign-in for staff and for members (student, parent, teacher, school). Generic errors only (no hint whether the e-mail
 * exists). Staff go to the console, members to their account; a sign-in that is neither is signed out again.
 */
export async function signIn(_prev: FormState, data: FormData): Promise<FormState> {
  const { ip } = await client();
  if (!(await consumeRateLimit("login", ip)).allowed) return { error: "Too many attempts. Please wait fifteen minutes." };
  const parsed = credentials.safeParse({ email: data.get("email"), password: data.get("password") });
  if (!parsed.success) return { error: "Enter your e-mail and password." };
  const supabase = await createSupabaseServerClient();
  if (!supabase) return { error: "Sign-in is not configured yet." };
  const { data: auth, error } = await supabase.auth.signInWithPassword(parsed.data);
  // Only reached with the right password, so naming the unconfirmed address reveals nothing to a stranger.
  if (error && classifyAuthError(error) === "unconfirmed") return { error: "Please confirm your e-mail address first: open the link we sent you, then sign in.", unconfirmed: true };
  if (error || !auth.user) return { error: "Those details did not match an account." };
  const destination = await destinationAfterSignIn(supabase, auth.user.id, data.get("next"));
  if (destination) redirect(destination);
  await supabase.auth.signOut();
  return { error: "This account is not set up yet. Create an account from this page, or contact the academy." };
}

export async function signOut() {
  const supabase = await createSupabaseServerClient();
  await supabase?.auth.signOut();
  redirect("/admin/login");
}

/** Always answers the same way, so the form cannot be used to discover which e-mails have accounts. */
export async function requestPasswordReset(_prev: FormState, data: FormData): Promise<FormState> {
  const { ip, host, proto } = await client();
  if (!(await consumeRateLimit("login", ip)).allowed) return { error: "Too many attempts. Please wait fifteen minutes." };
  const email = z.string().trim().email().max(160).safeParse(data.get("email"));
  if (!email.success) return { error: "Enter a valid e-mail address." };
  const supabase = await createSupabaseServerClient();
  if (!supabase) return { error: "Password reset is not configured yet." };
  const origin = process.env.NEXT_PUBLIC_SITE_URL || (host ? `${proto}://${host}` : "");
  await supabase.auth.resetPasswordForEmail(email.data, { redirectTo: `${origin}/auth/confirm?next=/admin/reset` });
  return { notice: "If that address belongs to an account, a reset link is on its way. It expires in one hour." };
}

const strongPassword = z.string().min(12, "Use at least 12 characters.").max(200).refine((p) => /[a-zA-Z]/.test(p) && /\d/.test(p), "Use letters and at least one number.");

export async function updatePassword(_prev: FormState, data: FormData): Promise<FormState> {
  const supabase = await createSupabaseServerClient();
  if (!supabase) return { error: "Not configured." };
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return { error: "Your reset link has expired. Request a new one." };
  const pw = strongPassword.safeParse(data.get("password"));
  if (!pw.success) return { error: pw.error.issues[0]?.message ?? "Choose a stronger password." };
  if (pw.data !== data.get("confirm")) return { error: "The two passwords do not match." };
  const { error } = await supabase.auth.updateUser({ password: pw.data });
  if (error) return { error: "The password could not be changed. Request a new link and try again." };
  redirect("/account"); // staff without a member profile are passed on to the console from there
}

const NOT_UPDATED = "Nothing was saved: this enquiry was not found, or your account can no longer change it.";

/**
 * Lead status change: staff only (checked first, before any input is read); RLS + column grants allow only
 * status/assignee; the change is audited in the database. `.select("id")` returns the updated rows, so a row hidden
 * by RLS reports "nothing saved" instead of a false success.
 */
export async function setLeadStatus(_prev: FormState, data: FormData): Promise<FormState> {
  const { supabase } = await requireStaff();
  const id = uuidSchema.safeParse(data.get("id"));
  const status = z.enum(LEAD_STATUSES).safeParse(data.get("status"));
  if (!id.success || !status.success) return { error: "Choose one of the listed statuses." };
  const { data: rows, error } = await supabase.from("onboarding_leads").update({ status: status.data }).eq("id", id.data).select("id");
  if (error) {
    logAdminError("admin.lead_status_failed", error);
    return { error: "The status was not saved. Please try again." };
  }
  if (!rows?.length) return { error: NOT_UPDATED };
  revalidatePath("/admin", "layout"); // list, detail and audit log all show it
  return { notice: `Status saved: ${status.data}.` };
}

/**
 * "Assign to me": updates ONLY assigned_to, and only ever to the signed-in staff member's own id (taken from the
 * verified session, never from the form). Staff check first.
 */
export async function assignLeadToMe(_prev: FormState, data: FormData): Promise<FormState> {
  const { supabase, user } = await requireStaff();
  const id = uuidSchema.safeParse(data.get("id"));
  if (!id.success) return { error: "That enquiry reference is not valid." };
  const { data: rows, error } = await supabase.from("onboarding_leads").update({ assigned_to: user.id }).eq("id", id.data).select("id");
  if (error) {
    logAdminError("admin.lead_assign_failed", error);
    return { error: "The enquiry was not assigned. Please try again." };
  }
  if (!rows?.length) return { error: NOT_UPDATED };
  revalidatePath("/admin", "layout");
  return { notice: "Assigned to you." };
}

/** Website image upload to the public `website-assets` bucket (staff only; type sniffed from the bytes). */
export async function uploadMedia(_prev: FormState, data: FormData): Promise<FormState> {
  const { supabase, user } = await requireStaff();
  const file = data.get("file");
  const alt = z.string().trim().min(3, "Describe the image (alt text).").max(300).safeParse(data.get("alt"));
  if (!(file instanceof File)) return { error: "Choose an image." };
  if (!alt.success) return { error: alt.error.issues[0]?.message ?? "Add alt text." };
  const bytes = new Uint8Array(await file.arrayBuffer());
  const check = validateUpload(bytes, "website-assets");
  if (!check.ok) return { error: check.error };
  const path = objectPath("site", check.type.ext);
  const { error: upErr } = await supabase.storage.from("website-assets").upload(path, bytes, { contentType: check.type.mime, upsert: false });
  if (upErr) return { error: "Upload failed. Nothing was saved." };
  const { error: rowErr } = await supabase.from("media_assets").insert({ storage_path: path, alt_text: alt.data, mime_type: check.type.mime, bytes: bytes.length, uploaded_by: user.id });
  if (rowErr) {
    await supabase.storage.from("website-assets").remove([path]);
    return { error: "The image could not be recorded, so it was removed again." };
  }
  revalidatePath("/admin/media");
  return { notice: "Uploaded." };
}

export async function deleteMedia(data: FormData) {
  const { supabase } = await requireStaff();
  const id = z.string().uuid().safeParse(data.get("id"));
  if (!id.success) return;
  const { data: row } = await supabase.from("media_assets").select("storage_path").eq("id", id.data).maybeSingle();
  if (!row) return;
  await supabase.storage.from("website-assets").remove([row.storage_path]);
  await supabase.from("media_assets").delete().eq("id", id.data);
  revalidatePath("/admin/media");
}
