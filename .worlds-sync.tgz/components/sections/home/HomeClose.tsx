"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { FilmImage } from "@/components/film/FilmImage";
import { HomeHeadline as Headline } from "./HomeTypography";
import { Arrow, Cta, Label } from "@/components/film/Marks";
import { CommandTeaser } from "@/components/sections/command/CommandExperience";
import { chronicle, finale } from "@/lib/content/home";
import { posts } from "@/lib/content/journal";
import { entity } from "@/lib/content/site";
import { ease } from "@/lib/motion/tokens";
import { cn } from "@/lib/utils";
import { BrassBorder } from "@/components/motion/fx/BrassBorder";

/** §13 Command AI · S13 terminal. Signature: the question types itself, the answer streams in. */
export function HomeCommand() {
  return <CommandTeaser />;
}

/** §14 The Chronicle · S14 editorial index. Signature: the cover swaps as you move down the headlines. */
export function HomeChronicle() {
  const list = posts.slice(0, 4);
  const [i, setI] = useState(0);
  const p = list[i];

  return (
    <section aria-labelledby="chronicle-h" className="relative py-[clamp(6rem,14vh,12rem)]">
      <div className="gutter">
        <Label reel={15}>The Chronicle</Label>
        <Headline id="chronicle-h" className="mt-4" inscription={chronicle.inscription} voice={chronicle.voice} />
      </div>
      <div className="gutter mt-12 grid gap-10 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
        <Link href={`/journal/${p.slug}`} className="group relative block">
          <div className="relative aspect-[4/3] overflow-hidden">
          <AnimatePresence mode="popLayout">
            <motion.div key={p.slug} className="absolute inset-0" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.8, ease: ease.citadel }}>
              <FilmImage name={p.cover} sizes="(min-width: 1024px) 55vw, 100vw" />
            </motion.div>
          </AnimatePresence>
          </div>
          <div className="relative py-6">
            <p className="label text-brass">
              {p.category} · {p.minutes} min read
            </p>
            <p className="t-voice mt-2 text-display-3 text-bone">{p.title.join(" ")}</p>
          </div>
        </Link>
        <ol className="border-t border-line">
          {list.map((post, k) => (
            <li data-home-detail key={post.slug}>
              <Link
                href={`/journal/${post.slug}`}
                onMouseEnter={() => setI(k)}
                onFocus={() => setI(k)}
                className="group grid grid-cols-[2rem_1fr] gap-3 border-b border-line py-6"
              >
                <span className="font-mono pt-1 text-xs text-dust">{String(k + 1).padStart(2, "0")}</span>
                <span>
                  <span className={cn("t-voice block text-xl transition-colors md:text-2xl", i === k ? "text-gold" : "text-bone group-hover:text-gold")}>
                    {post.title.join(" ")}
                  </span>
                  <span className="mt-2 block text-sm text-sand/80">{post.dek}</span>
                </span>
              </Link>
            </li>
          ))}
          <li className="pt-8">
            <Cta href="/journal" variant="link">
              Read the Chronicle
            </Cta>
          </li>
        </ol>
      </div>
    </section>
  );
}

/** §15 Finale · S15 The Arena is Open · Stealth Bomber & Snow Gallop Finale */
export function Finale() {
  return (
    <section aria-label="The arena is open" className="relative tone-photo surface-leather min-h-[100svh] overflow-hidden bg-night">
      <FinaleFrame />
    </section>
  );
}

function FinaleFrame({ inline = false }: { inline?: boolean }) {
  return (
    <div className={cn("relative min-h-[100svh] w-full flex items-center justify-center py-12 md:py-16 overflow-hidden bg-night", inline && "min-h-full py-0")}>
      {/* Edge-to-edge full screen cinematic background image */}
      <FilmImage name="duneSilhouette" grade="deep" className="opacity-100" />
      {/* A soft dark pool behind the copy so the headline and its gold second line read on the pale sky (2 Nov 2026). */}
      <div aria-hidden className="pointer-events-none absolute inset-0 z-10 bg-[radial-gradient(ellipse_60%_45%_at_50%_45%,rgb(23_21_19/0.62),rgb(23_21_19/0.25)_60%,transparent_85%)]" />

      {/* Minimized, Elegant Editorial Content */}
      <div data-home-final-copy className="relative mx-auto max-w-5xl px-6 py-8 text-center z-20 flex flex-col items-center">
        {/* R13 (2 Nov 2026): "The arena is open." is the headline, large and bold; the legacy line is its quieter second voice. */}
        <h2 data-home-final-title className="[text-shadow:0_2px_18px_rgba(0,0,0,0.85)]">
          <span className="t-inscribe block text-[clamp(2.6rem,8vw,6.5rem)] font-semibold leading-[0.95] tracking-[0.02em] text-bone">
            {finale.inscription}
          </span>
          <span className="t-voice mt-4 block text-[clamp(1.35rem,3.2vw,2.4rem)] leading-tight text-gold [text-shadow:0_1px_10px_rgba(0,0,0,0.9)]">
            {finale.voice}
          </span>
        </h2>

        {/* Action Buttons - Sleek, Compact Luxury Pills */}
        <div data-home-detail className="mt-8 flex flex-wrap justify-center gap-3">
          {finale.ctas.map((c, i) =>
            i === 0 ? (
              <BrassBorder key={c.href} as={Link} href={c.href} className="tone-dark group bg-night px-5 py-3 text-bone sm:px-7 sm:py-4">
                <span>{c.label}</span>
                <Arrow className="transition-transform group-hover:translate-x-1" />
              </BrassBorder>
            ) : (
              <Link
                key={c.href}
                href={c.href}
                className="tone-dark label group inline-flex items-center gap-3 border border-line bg-night/85 px-5 py-3 text-sand transition-colors hover:border-gold hover:text-bone sm:px-7 sm:py-4"
              >
                <span>{c.label}</span>
                <Arrow className="transition-transform group-hover:translate-x-1" />
              </Link>
            ),
          )}
        </div>

        {/* Motto & Reel One Link */}
        <p className="mt-5 font-serif italic text-xs sm:text-sm text-sand/80 [text-shadow:0_1px_8px_rgba(0,0,0,0.8)]">
          {entity.motto}. {entity.mottoEn}.
        </p>
        <Link
          href="/legend"
          className="mt-2 inline-flex min-h-6 items-center gap-2 font-mono text-[0.66rem] uppercase tracking-[0.22em] text-gold hover:text-bone transition-colors"
        >
          <span>Begin at reel one</span>
          <Arrow />
        </Link>
      </div>
    </div>
  );
}
