"use client";

import { useEffect, useRef, useState } from "react";
import { useLenis } from "lenis/react";
import { useReducedMotion } from "@/lib/motion/reduced";
import { saveDataMode } from "@/lib/motion/save-data";
import { asset } from "@/lib/content/asset";

type Playback = "loading" | "buffering" | "playing" | "paused" | "blocked" | "failed" | "ended" | "skipped";

/** Existing opening film, with device-sized sources and a useful still at every failure state. */
export function HeroFilm() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const progressRef = useRef<HTMLSpanElement>(null);
  const bufferedRef = useRef<HTMLSpanElement>(null);
  const userPaused = useRef(false);
  const scrubbing = useRef(false);
  const seekRef = useRef<HTMLDivElement>(null);
  const inView = useRef(true);
  const failed = useRef(false);
  const [state, setState] = useState<Playback>("loading");
  const [muted, setMuted] = useState(true);
  const [hasFrame, setHasFrame] = useState(false);
  // The film opens on its title card (2.8 s). Seeking there before the first frame plays would replace the poster,
  // so the jump happens only when playback starts, and the video stays hidden from that seek until it is playing
  // (the <picture> poster underneath shows meanwhile, exactly as before). Until then the <video> shows its own
  // poster, which is the same still: the hero is painted from the first frame instead of only once the film plays
  // (that late reveal used to be the page's LCP).
  const primed = useRef(false);
  const [seeked, setSeeked] = useState(false);
  // On phones the status line takes its own row, so every brief stall (common while the page is still starting)
  // used to push the page down and back up (layout shift). It now appears only if buffering lasts over a second.
  const [longStall, setLongStall] = useState(false);
  useEffect(() => {
    if (state !== "buffering") return;
    const timer = window.setTimeout(() => setLongStall(true), 1000);
    return () => { window.clearTimeout(timer); setLongStall(false); };
  }, [state]);
  const reduced = useReducedMotion();
  const lenis = useLenis();

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    let disposed = false;
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    // Data Saver or a 2G link: the film stays on its poster (the 3 to 8 MB file is never played), like reduced motion.
    const saveData = saveDataMode();
    const failure = () => { failed.current = true; if (!disposed) setState("failed"); };
    // Source errors can happen before hydration and do not bubble from <source>.
    // Inspect the native state too, including the all-sources-failed browser case.
    const mediaStarted = performance.now();
    const watchdog = window.setInterval(() => {
      if (video.networkState === HTMLMediaElement.NETWORK_NO_SOURCE || (!preference.matches && !saveData && video.readyState < 2 && performance.now() - mediaStarted > 12000)) failure();
      if (video.readyState >= 2 || failed.current) window.clearInterval(watchdog);
    }, 200);
    // The film starts when the loader (and the opening zoom) has gone, so none of it plays unseen behind the overlay.
    const holding = () => !!document.querySelector(".bsah-loader");
    const sync = () => {
      if (holding()) video.pause();
      else if (document.hidden || !inView.current || userPaused.current || preference.matches || saveData) video.pause();
      else { prime(); video.play().catch(() => { if (!disposed) setState((previous) => failed.current || previous === "failed" ? "failed" : "blocked"); }); }
    };
    const observer = new IntersectionObserver(([entry]) => { inView.current = entry.isIntersecting; sync(); }, { threshold: 0.05 });
    observer.observe(video);
    document.addEventListener("visibilitychange", sync);
    window.addEventListener("bsah:loader-gone", sync);
    preference.addEventListener("change", sync);
    sync();
    return () => { disposed = true; clearInterval(watchdog); observer.disconnect(); document.removeEventListener("visibilitychange", sync); window.removeEventListener("bsah:loader-gone", sync); preference.removeEventListener("change", sync); video.pause(); };
  }, []);

  /** Jump to the title card once, just before the first playback (needs metadata; otherwise onLoadedMetadata does it). */
  function prime() {
    const video = videoRef.current;
    if (!video || primed.current || video.readyState < HTMLMediaElement.HAVE_METADATA) return;
    primed.current = true;
    if (video.currentTime < 2.8) { setSeeked(true); video.currentTime = Math.min(2.8, video.duration || 2.8); }
  }
  const updateProgress = () => {
    const video = videoRef.current;
    if (!video || !Number.isFinite(video.duration) || video.duration <= 0) return;
    if (progressRef.current) progressRef.current.style.transform = `scaleX(${video.currentTime / video.duration})`;
    seekRef.current?.setAttribute("aria-valuenow", String(Math.round(100 * video.currentTime / video.duration)));
    if (bufferedRef.current && video.buffered.length) bufferedRef.current.style.transform = `scaleX(${video.buffered.end(video.buffered.length - 1) / video.duration})`;
  };
  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    userPaused.current = !video.paused;
    if (video.paused) { prime(); video.play().catch(() => setState((previous) => previous === "failed" ? previous : "blocked")); }
    else video.pause();
  };
  const skip = () => {
    userPaused.current = true;
    videoRef.current?.pause();
    setState("skipped");
    // Skipping lands on the animated stallion that follows the film.
    const target = document.getElementById("stallion") ?? document.getElementById("doctrine");
    if (!target) return;
    if (lenis && !reduced) lenis.scrollTo(target, { immediate: true });
    else target.scrollIntoView({ behavior: "instant" });
    target.focus({ preventScroll: true });
  };
  const seekFromPointer = (clientX: number, el: HTMLElement) => {
    const video = videoRef.current;
    if (!video || !Number.isFinite(video.duration) || video.duration <= 0) return;
    const rect = el.getBoundingClientRect();
    video.currentTime = Math.min(1, Math.max(0, (clientX - rect.left) / Math.max(1, rect.width))) * video.duration;
    updateProgress();
  };
  const seekBy = (seconds: number) => {
    const video = videoRef.current;
    if (!video || !Number.isFinite(video.duration)) return;
    video.currentTime = Math.min(video.duration, Math.max(0, video.currentTime + seconds));
    updateProgress();
  };
  const playing = state === "playing";

  // The film is a scope picture (about 2.5:1) delivered inside 16:9 files with black bars baked in (the picture is 71 % of the frame's
  // height: rows 130 to 770 of 900), and its title cards run across 71 % of the picture's width. So the film fills the first screen as
  // far as it can without cutting a word: the frame is made 1.28 screens wide (the picture then shows 78 % of itself, the title cards
  // whole) and the picture's soft top and bottom edges dissolve into the dark of the screen, where the baked bars are. On a phone the
  // same rule makes a band across the middle of the dark, under the dust.
  // 4 Nov 2026 (owner): no empty bands. The section is cut to the picture itself (about 1.95:1 of the screen's width), so
  // the film sits edge to edge between the doctrine and the stallion with no black or cream bars above or below it.
  const FRAME_ASPECT = "1606 / 900";
  return <section id="top" aria-label="Opening Film" data-playback={state} className="tone-photo relative aspect-[1.95/1] w-full overflow-hidden bg-night">
    {/* 31 Oct 2026 (owner's request): no picture behind the film. Around the frame the screen is plain black on phone and
        desktop, and the frame's edges are cut clean where the baked bars begin (they used to dissolve into a dust still). */}
    <div className="absolute left-1/2 top-1/2 w-[130vw] -translate-x-1/2 -translate-y-1/2 md:w-[128%]" style={{ aspectRatio: FRAME_ASPECT, maskImage: "linear-gradient(to bottom, transparent 14.6%, black 14.6%, black 85.4%, transparent 85.4%)", WebkitMaskImage: "linear-gradient(to bottom, transparent 14.6%, black 14.6%, black 85.4%, transparent 85.4%)" }}>
      <picture className="absolute inset-0">
        <source media="(max-width: 767px)" srcSet={asset("/video/hero-main-poster-mobile.webp")} />
        {/* Native picture is deliberately available before JS and video decoding. */}
        <img data-hero-poster src={asset("/video/hero-main-poster.webp")} alt="Marwari stallions in the academy opening film" fetchPriority="high" className="h-full w-full object-cover" />
      </picture>
      <video ref={videoRef} className={`absolute inset-0 h-full w-full object-cover ${state !== "failed" && (hasFrame || !seeked) ? "opacity-100" : "opacity-0"}`} muted loop playsInline preload="metadata" poster={asset("/video/hero-main-poster.webp")} aria-label="The Marwari Stallion opening film"
        onLoadedMetadata={() => { if (videoRef.current && !videoRef.current.paused) prime(); updateProgress(); }}
        onPlaying={() => { failed.current = false; setHasFrame(true); setState("playing"); }} onPause={() => setState((previous) => previous === "skipped" || previous === "failed" ? previous : "paused")}
        onWaiting={() => setState((previous) => failed.current || previous === "failed" ? "failed" : "buffering")} onStalled={() => setState((previous) => previous === "playing" ? "buffering" : previous)} onEnded={() => setState("ended")}
        onError={() => { failed.current = true; setState("failed"); }} onTimeUpdate={updateProgress} onProgress={updateProgress} onVolumeChange={(event) => setMuted(event.currentTarget.muted)}>
        {/* No onError on <source>: a source whose media query does not match fires "error" when it is skipped, which
            wrongly marked the film as failed on wide screens. Real failures are caught by the video's own error
            event and by the NETWORK_NO_SOURCE watchdog above. */}
        <source media="(max-width: 767px)" src={asset("/video/hero-main-mobile.mp4")} type="video/mp4" />
        <source src={asset("/video/hero-main-desktop.mp4")} type="video/mp4" />
      </video>
    </div>

    {/* Controls sit on the foot of the screen (never in the top 80 px, which belongs to the nav). */}
    <div data-sound="off" className="no-print gutter absolute inset-x-0 bottom-0 z-10 flex flex-wrap items-center justify-end sm:justify-between gap-x-3 gap-y-2 pb-3 pt-6 md:pb-7 md:pt-12">
      <button type="button" onClick={skip} className="label hidden min-h-11 rounded-full border border-brass/50 bg-night/40 px-4 text-sand backdrop-blur-[2px] hover:text-gold sm:inline-block">Skip intro</button>
      <p className="order-last w-full text-center text-xs text-sand sm:order-none sm:w-auto sm:flex-1" role="status" aria-live="polite">
        {state === "buffering" ? (longStall ? "Buffering film…" : null) : state === "failed" ? "The film is unavailable. Continue to explore the academy." : state === "blocked" ? "Press play to watch the opening film." : null}
      </p>
      <div className="flex items-center gap-2">
        <button type="button" disabled={state === "failed"} onClick={() => seekBy(-10)} aria-label="Back 10 seconds" className="label hidden h-11 min-w-11 place-items-center sm:grid rounded-full border border-brass/50 bg-night/40 px-3 text-xs text-sand backdrop-blur-[2px] hover:text-gold disabled:opacity-40">-10s</button>
        <button type="button" disabled={state === "failed"} onClick={() => seekBy(10)} aria-label="Forward 10 seconds" className="label hidden h-11 min-w-11 place-items-center sm:grid rounded-full border border-brass/50 bg-night/40 px-3 text-xs text-sand backdrop-blur-[2px] hover:text-gold disabled:opacity-40">+10s</button>
        <button type="button" disabled={state === "failed"} onClick={() => { if (videoRef.current) videoRef.current.muted = !videoRef.current.muted; }} aria-pressed={!muted} aria-label={muted ? "Sound off. Unmute the film" : "Sound on. Mute the film"} className="label min-h-9 rounded-full border border-brass/50 bg-night/40 px-3 text-[0.6rem] text-sand backdrop-blur-[2px] hover:text-gold disabled:opacity-50 sm:min-h-11 sm:px-4 sm:text-[inherit]">Sound {muted ? "off" : "on"}</button>
        <button type="button" disabled={state === "failed"} onClick={togglePlay} aria-label={playing ? "Pause the film" : "Play the film"} className="grid h-9 w-9 place-items-center rounded-full border border-brass/50 bg-night/40 sm:h-11 sm:w-11 text-sand backdrop-blur-[2px] hover:text-gold disabled:opacity-50"><span aria-hidden>{playing ? "Ⅱ" : "▶"}</span></button>
      </div>
    </div>
    {/* Seek bar along the bottom edge: drag, click or touch anywhere on it to scrub, like a video player. Arrow keys step 5 s (Shift: 10 s). */}
    <div ref={seekRef} role="slider" tabIndex={0} aria-label="Seek the opening film" aria-valuemin={0} aria-valuemax={100} aria-valuenow={0} data-seek
      className="absolute inset-x-0 bottom-0 z-10 h-6 cursor-pointer touch-none select-none outline-none focus-visible:ring-2 focus-visible:ring-gold/70"
      onPointerDown={(event) => { if (state === "failed") return; event.currentTarget.setPointerCapture(event.pointerId); scrubbing.current = true; seekFromPointer(event.clientX, event.currentTarget); }}
      onPointerMove={(event) => { if (scrubbing.current) seekFromPointer(event.clientX, event.currentTarget); }}
      onPointerUp={() => { scrubbing.current = false; }}
      onPointerCancel={() => { scrubbing.current = false; }}
      onKeyDown={(event) => {
        const step = event.shiftKey ? 10 : 5;
        const video = videoRef.current;
        if (!video) return;
        if (event.key === "ArrowRight") seekBy(step);
        else if (event.key === "ArrowLeft") seekBy(-step);
        else if (event.key === "Home") video.currentTime = 0;
        else if (event.key === "End") video.currentTime = video.duration || 0;
        else return;
        event.preventDefault();
      }}>
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[3px] bg-night/50" aria-hidden>
        <span ref={bufferedRef} className="absolute inset-0 origin-left bg-brass/40" style={{ transform: "scaleX(0)" }} />
        <span ref={progressRef} className="absolute inset-0 origin-left bg-gold" style={{ transform: "scaleX(0)" }} />
      </div>
    </div>
  </section>;
}
